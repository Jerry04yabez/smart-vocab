# smart_vocab
AI powered smart vocabulary learning web application
